# Cloud-Based Smart Inventory Management System
This project is a scalable, cloud-native inventory management system built with Django, PostgreSQL, and Google Cloud Platform (GCP).
## Features
- RESTful API for inventory management
- Integrated with Google Cloud SQL and Cloud Storage
- Deployed using Docker and Kubernetes
## Installation
1. Clone the repository and navigate to the project directory.
2. Build and run the application using Docker:
   ```bash
   docker-compose up --build
   ```
3. Access the application at `http://localhost:8000`.
## License
[MIT License](LICENSE)